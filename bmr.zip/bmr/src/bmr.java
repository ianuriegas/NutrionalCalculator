import java.util.*;


public class bmr {

    
    public static final Scanner scnr = new Scanner(System.in);
    public static void main(String[] args) {
        String line = "--------------------------------------------------------------------------------------------------------------------------";
        double weight;
        double height;
        double age;
        String gender;


        
        System.out.print("Enter your first name: ");
        String name = scnr.next();
        System.out.println(line);
        
        System.out.println("Welcome "+ name +" to my calorie calculator. The Objective of this program is to determine the amount of calories you would need to intake based on your lifestyle");
        System.out.println(line);
        
        System.out.print("Enter your bodyweight in pounds: "); // takes weight
        weight = scnr.nextInt();
        
        System.out.print("Enter your height in inches: "); // take height
        height = scnr.nextInt();
        
        System.out.print("Enter your age: "); // take height
        age = scnr.nextInt();
        
        System.out.print("Enter your gender (man or woman): "); // take gender
        gender = scnr.next();
        gender = gender.toLowerCase();
        System.out.println(line);
        
        
        double mensBMR = (4.536*weight)+(15.88*height)-(5*age)+5;
        double womensBMR = (4.536*weight)+(15.88*height)-(5*age)-161;
        
        if(gender.contains("man")||gender.contains("men")||gender.contains("boy")){
            int intMensBMR = (int) mensBMR;
            System.out.println("Your basal metabolic rate is roughly: " + intMensBMR + " calories");
            
        }
        else if (gender.contains("woman")||gender.contains("women")||gender.contains("girl")){
            int intWomensBMR = (int) womensBMR;
            System.out.println("Your basal metabolic rate is roughly: " + intWomensBMR + " calories");
            
        }
        else{
            System.out.println(gender + " is not a gender listed");
            return;
        }
        System.out.println(line);
        
        System.out.println("Pick a statement below that describes your activity level");
        System.out.println("1 - Sedentary (little or no exercise)");
        System.out.println("2 - Lightly active (light exercise/sports 1-3 days/week)");
        System.out.println("3 - Moderately active (moderate exercise/sports 3-5 days/week)");
        System.out.println("4 - Very active (hard exercise/sports 6-7 days a week)");
        System.out.println("5 - Extra active (very hard exercise/sports & a physical job)");
        System.out.println(line);
        int activityLevel = scnr.nextInt();
        String based = "Based on your activity level your maintenence calories would be around: ";
        System.out.println(line);
        switch (activityLevel) {
            case 1:
                {
                    mensBMR=mensBMR*1.2;
                    int intMensBMR = (int) mensBMR;
                    System.out.println(based + intMensBMR + " calories");
                    System.out.println(line);
                    break;
                }
            case 2:
                {
                    mensBMR=mensBMR*1.375;
                    int intMensBMR = (int) mensBMR;
                    System.out.println(based + intMensBMR + " calories");
                    System.out.println(line);
                    break;
                }
            case 3:
                {
                    mensBMR=mensBMR*1.55;
                    int intMensBMR = (int) mensBMR;
                    System.out.println(based + intMensBMR + " calories");
                    System.out.println(line);
                    break;
                }
            case 4:
                {
                    mensBMR=mensBMR*1.725;
                    int intMensBMR = (int) mensBMR;
                    System.out.println(based + intMensBMR + " calories");
                    System.out.println(line);
                    break;
                }
            case 5:
                {
                    mensBMR=mensBMR*1.9;
                    int intMensBMR = (int) mensBMR;
                    System.out.println(based + intMensBMR + " calories");
                    System.out.println(line);
                    break;
                }
            default:
                System.out.println(activityLevel + " is not a valid input");
                return;
        }

        System.out.println("Were you thinking about bulking, cutting or maintaining your current weight of " + weight + " pounds?");
        String bcm = scnr.next();
        bcm = bcm.toLowerCase();
        System.out.println(line);
        
        
        if(bcm.contains("bulking")||bcm.contains("bulk")){
            double bulk = mensBMR + 200.0;
            int intMensBMR = (int) bulk;
            System.out.println("For bulking you would typically increase your caloric intake by 200 calories from your maintianence, which would be : " + intMensBMR + " calories");
        }
        else if(bcm.contains("cutting")||bcm.contains("cut")){
            double bulk = mensBMR - 200.0;
            int intMensBMR = (int) bulk;
            System.out.println("For cutting you would typically decrease your caloric intake by 200 calories from your maintianence, which would be " + intMensBMR + " calories");
        }
        else{
            System.out.println("Are you unfamiliar with bulking, cutting and maintaining?");
        }
        
    }
}
